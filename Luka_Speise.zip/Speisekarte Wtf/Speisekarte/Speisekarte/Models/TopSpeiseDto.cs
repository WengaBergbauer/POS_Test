﻿
    public class TopSpeiseDto
    {
        public string Speise { get; set; }
        public int Sterne { get; set; }
    }

