﻿namespace JobPortal.Models
{
    public class JobPosting
    {
        public int Id { get; set; }
        public string JobTitle { get; set; }
        public string JobLocation { get; set; }
        public string JobDescription { get; set; }
        public float Salary { get; set; }
        public DateTime StartDate { get; set; }
        public string? CompanyName { get; set; }
        public byte[] CompanyImage { get; set; }
        public string? OwnerUsername { get; set; }
    }
}
