﻿using Menu.Models;
using Microsoft.EntityFrameworkCore;

namespace Menu.Data
{
    public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
    {
        public DbSet<Ingredient> Ingredients { get; set; }
        public DbSet<MenuItem> Items { get; set; }
    }
}
