﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Menu.Models
{
    public class Ingredient
    {
        public Guid Id { get; set; }

        [Required, MaxLength(100)]
        public string Description { get; set; } = string.Empty;

        public string Einheit { get; set; } = string.Empty;
        public string Unit { get; set; } = string.Empty;

        [Required]
        public decimal Quantity { get; set; }

        [JsonIgnore]
        public MenuItem? MenuItem { get; set; } = null!;

        public Guid MenuItemId { get; set; }

        public override string ToString()
        {
            return $"{Quantity} {Unit} {Description}";
        }
    }
}
