﻿using System.ComponentModel.DataAnnotations;

namespace Menu.Models
{
    public class MenuItem
    {
        public Guid Id { get; set; }

        [Required, MinLength(5)]
        public string Name { get; set; }
        public string? Notices { get; set; }

        [Required]
        public int numberOfStars { get; set; }

        public IEnumerable<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
    }
}
