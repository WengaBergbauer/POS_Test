﻿using Menu.Data;
using Menu.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Menu.Controllers
{
    public class MenuItemsUIController(ApplicationDbContext context) : Controller
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IActionResult> Index()
        {
            var items = await _context.Items
                .ToListAsync();

            return View(items);
        }

        public async Task<IActionResult> Details(Guid itemId)
        {
            var items = await _context.Items
                .ToListAsync();

            ViewBag.Item = await _context.Items
                .Where(i => i.Id == itemId)
                .Include(i => i.Ingredients)
                .SingleOrDefaultAsync();

            if (ViewBag.Item is null)
            {
                return NotFound();
            }

            return View("Index", items);
        }

        public async Task<IActionResult> CreateMenuItem(MenuItem? menuItem)
        {
            ViewBag.StarSelectListItems = new List<SelectListItem>() {
                new() { Text = "Very very gooood", Value = "5" },
                new() { Text = "Not sooo good", Value = "3" },
                new() { Text = "Veryy baddd", Value = "0" },
            };

            if (!ModelState.IsValid || menuItem is null) {
                return View(menuItem);
            }

            _context.Items.Add(menuItem);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { itemId = menuItem.Id });
        }

        public async Task<IActionResult> CreateIngredient([FromQuery] Guid itemId, Ingredient? ingredient)
        {
            ingredient.MenuItemId = itemId;

            ViewBag.MenuItemId = itemId;

            if (!ModelState.IsValid || ingredient is null)
            {
                return View(ingredient);
            }

            _context.Ingredients.Add(ingredient);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { itemId = ingredient.MenuItemId });
        }

        public async Task<IActionResult> Delete(Guid itemId)
        {
            
            var item = await _context.Items.FirstOrDefaultAsync();

            if (item is null)
            {
                return NotFound();
            }

            _context.Items.Remove(item);

            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
