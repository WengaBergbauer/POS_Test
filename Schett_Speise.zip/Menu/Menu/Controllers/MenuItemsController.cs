﻿using Menu.Data;
using Menu.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace Menu.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuItemsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public MenuItemsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("predefined")]
        public async Task<IActionResult> CreatePredefinedItem()
        {
            MenuItem item = new()
            {
                Name = "Pizza",
                Notices = "Gluten free",
                numberOfStars = 5,
                Ingredients = [
                    new()
                    {
                        Description = "Haufenweise Fett",
                        Unit = "kg",
                        Quantity = 4,
                    },
                    new()
                    {
                        Description = "Haufenweise Mehl",
                        Unit = "kg",
                        Quantity = 3,
                    },
                    new()
                    {
                        Description = "Tonnenweise Käse",
                        Unit = "kg",
                        Quantity = 2,
                    }
                ]
            };

            _context.Items.Add(item);
            await _context.SaveChangesAsync();

            return StatusCode((int) HttpStatusCode.Created, item);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllMenuItems()
        {
            var items = await _context.Items
                .Include(item => item.Ingredients)
                .ToListAsync();

            return Ok(items);
        }

        [HttpPost]
        public async Task<IActionResult> CreateMenuItem(MenuItem item)
        {
            _context.Items.Add(item);

            await _context.SaveChangesAsync();

            return Ok(item);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var item = await _context.Items.FirstOrDefaultAsync();

            if (item is null)
            {
                return NotFound();
            }

            _context.Items.Remove(item);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
